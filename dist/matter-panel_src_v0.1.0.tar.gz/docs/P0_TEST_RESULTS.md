# P0 联调结果表

> 跑完直接填，汇总行自动计算
> **Mock ≠ Real，分开记录**

## 4 路主版

| 用例 | channelCount | envType | evidenceLevel | result | latencyMs | errorCode | boardType | transport | firmwareVersion | haVersion | 备注 |
|---|---:|---|---|---|---|---:|---|---|---|---|---|
| P0-01 首次配网成功 | 4 | real | hardware_real | | | | xiao_esp32c6 | wifi | | | 需物理设备 + Matter SDK |
| P0-02 HA 实体创建正确 | 4 | real | hardware_real | | | | xiao_esp32c6 | wifi | | | 需物理设备 + Matter SDK |
| P0-03 本地按键 -> HA 同步 | 4 | mock | integration_mock | pass | 403 | | — | — | | | mock 验证通过 |
| P0-04 HA 控制 -> 面板同步 | 4 | mock | integration_mock | pass | 403 | | — | — | | | mock 验证通过 |
| P0-05 连续快速操作稳定性 | 4 | mock | integration_mock | pass | 603 | | — | — | | | 10次操作0失败 |
| P0-06 断网状态识别 | 4 | mock | ui_flow | pass | 305 | | — | — | | | WS 断开模拟，仅状态流预演 |
| P0-07 网络恢复自动回连 | 4 | mock | ui_flow | pass | 1308 | | — | — | | | 重连+状态恢复预演，非真机恢复 |
| P0-08 设备重启恢复 | 4 | real | hardware_real | | | | xiao_esp32c6 | wifi | | | 需物理设备 |

## 2 路裁剪版

| 用例 | channelCount | envType | evidenceLevel | result | latencyMs | errorCode | boardType | transport | firmwareVersion | haVersion | 备注 |
|---|---:|---|---|---|---|---:|---|---|---|---|---|
| P0-01 首次配网成功 | 2 | real | hardware_real | | | | xiao_esp32c6 | wifi | | | 需物理设备 + Matter SDK |
| P0-03 本地按键 -> HA 同步 | 2 | mock | integration_mock | | | | — | — | | | 待裁剪版验证 |
| P0-04 HA 控制 -> 面板同步 | 2 | mock | integration_mock | | | | — | — | | | 待裁剪版验证 |
| P0-08 设备重启恢复 | 2 | real | hardware_real | | | | xiao_esp32c6 | wifi | | | 需物理设备 |

## Mock 正式通过

| 指标 | 结果 |
|---|---|
| Mock 控制成功率 | 100% |
| Mock P50 响应时延 | 403ms |
| Mock P90 响应时延 | 603ms |
| Mock 正式通过项 | P0-03 / P0-04 / P0-05 |
| Mock 阻塞数 | 0 |

## Mock Drill（状态流预演，不计入验收）

| 用例 | 结果 | 说明 |
|---|---|---|
| P0-06 断网状态识别 | pass | WS 断开模拟，仅 UI 状态流验证 |
| P0-07 网络恢复自动回连 | pass | 重连逻辑预演，非真实网络恢复 |

## 真机待验证项

| 用例 | channelCount | 阻塞原因 |
|---|---|---|
| P0-01 首次配网成功 | 4 / 2 | 无 esp-matter SDK / ESP32 开发板 |
| P0-02 HA 实体创建正确 | 4 / 2 | 无 esp-matter SDK / ESP32 开发板 |
| P0-06 断网状态识别 | 4 / 2 | 需真实网络断开 + 状态切换验证 |
| P0-07 网络恢复自动回连 | 4 / 2 | 需真实断网恢复 + 重连耗时测量 |
| P0-08 设备重启恢复 | 4 / 2 | 无 esp-matter SDK / ESP32 开发板 |

## 阻塞清单

| 阻塞项 | 影响用例 | 当前规避方案 | 需要谁配合 |
|---|---|---|---|
| esp-matter SDK / XIAO ESP32-C6 未就绪 | P0-01 / P0-02 / P0-06 / P0-07 / P0-08 | mock 先验 P0-03/04/05 状态同步链路 | hao side 提供 XIAO ESP32-C6 开发板或已配好的 esp-matter 环境 |

## 说明

- **Mock integration_mock** = 前端/状态流/HA 指令链路可用，不计入正式验收
- **Mock ui_flow** = 仅 UI 状态切换逻辑验证，非真实网络/恢复行为
- **Real hardware_real** = 才能计入正式 P0 验收和真实性能数据

## 下一步

1. 搭建 `esp-matter` SDK 编译环境（ESP-IDF v5.1+ + esp-matter v1.2+）
2. 烧录 4 路固件到 ESP32-S3 开发板
3. 接入真实 HA 实例跑 P0-01/02/08
4. `CHANNEL_COUNT=2` 编译验证裁剪版
